<?php
require_once __DIR__ . '/access.php';
require_page_access();

include 'db_connect.php';

if (isset($_POST['save'])) {
 $student = (int) $_POST['student_id'];
 $date = $_POST['attendance_date'];
 $status = $_POST['status'];

 if ($student > 0 && $date != '' &&
 ($status == 'Present' || $status == 'Absent')) {
 $stmt = mysqli_prepare($connection,
 "INSERT INTO attendance
 (student_id, attendance_date, status)
 VALUES (?, ?, ?)");
 mysqli_stmt_bind_param($stmt, 'iss',
 $student, $date, $status);

 if (mysqli_stmt_execute($stmt)) {
 echo '<p>Attendance saved successfully.</p>';
 } else {
 echo '<p>Could not save attendance.</p>';
 }
 mysqli_stmt_close($stmt);
 } else {
 echo '<p>Please enter valid details.</p>';
 }
}

$students = mysqli_query($connection,
 'SELECT * FROM student ORDER BY first_name');
?>

<link rel="stylesheet" href="badge_background.css">
<h2>Record Attendance</h2>
<form method="post">
 Student:
 <select name="student_id" required>
 <option value="">Select student</option>
 <?php while ($row = mysqli_fetch_assoc($students)) { ?>
 <option value="<?php echo $row['student_id']; ?>">
 <?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?>
 </option>
 <?php } ?>
 </select><br><br>

 Date: <input type="date" name="attendance_date" required><br><br>
 Status:
 <select name="status" required>
 <option value="">Select status</option>
 <option value="Present">Present</option>
 <option value="Absent">Absent</option>
 </select><br><br>
 <button type="submit" name="save">Save attendance</button>
</form>

<h2>Attendance Records</h2>
<table border="1" cellpadding="8">
 <tr><th>Student</th><th>Date</th><th>Status</th></tr>
 <?php
 $records = mysqli_query($connection,
 "SELECT student.first_name, student.last_name,
 attendance.attendance_date, attendance.status
 FROM attendance
 JOIN student ON attendance.student_id = student.student_id
 ORDER BY attendance.attendance_id DESC");

 while ($row = mysqli_fetch_assoc($records)) {
 echo '<tr>';
 echo '<td>' . htmlspecialchars($row['first_name'] . ' ' . $row['last_name']) . '</td>';
 echo '<td>' . htmlspecialchars($row['attendance_date']) . '</td>';
 echo '<td>' . htmlspecialchars($row['status']) . '</td>';
 echo '</tr>';
 }
 ?>
</table>

