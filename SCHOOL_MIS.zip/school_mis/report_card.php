<?php
require_once __DIR__ . '/access.php';
require_page_access();

include 'db_connect.php';

$students = mysqli_query($connection,
 'SELECT student_id, first_name, last_name
 FROM student ORDER BY first_name');
?>
<style>
@media print {
 form, button { display: none; }
}
</style>

<h1>Kazo Muslim Secondary School</h1>
<button type="button" onclick="window.location.href='index.php'">Back to Home</button>

<link rel="stylesheet" href="badge_background.css">
<h2>Student Results Report</h2>
<form method="post">
 Student:
 <select name="student_id" required>
 <option value="">Select student</option>
 <?php while ($student = mysqli_fetch_assoc($students)) { ?>
 <option value="<?php echo (int)$student['student_id']; ?>">
 <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?>
 </option>
 <?php } ?>
 </select><br><br>

 Term: <select name="term">
 <option>1</option><option>2</option><option>3</option>
 </select><br><br>
 Year: <input type="number" name="year" value="2026" min="2000" max="2100" required><br><br>
 Attendance start date: <input type="date" name="start_date" required><br><br>
Attendance end date: <input type="date" name="end_date" required><br><br>

 <button type="submit" name="view">View report</button>
</form>
<button onclick="window.print()">Print report</button>

<?php
if (isset($_POST['view'])) {
 $id = (int) $_POST['student_id'];
 $term = (int) $_POST['term'];
 $year = (int) $_POST['year'];
 $start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];
if ($end_date < $start_date) {
 echo '<p>End date must be on or after the start date.</p>';
 return;
}


 $stmt = mysqli_prepare($connection,
 "SELECT s.first_name, s.last_name, c.class_name, sub.subject_name, r.mark

 FROM result r
 JOIN student s ON r.student_id = s.student_id
 JOIN class c ON s.class_id = c.class_id
 JOIN subject sub ON r.subject_id = sub.subject_id
 WHERE r.student_id = ? AND r.term = ? AND r.year = ?
 ORDER BY sub.subject_name");
 mysqli_stmt_bind_param($stmt, 'iii', $id, $term, $year);
 mysqli_stmt_execute($stmt);
 mysqli_stmt_bind_result($stmt, $first, $last, $class, $subject, $mark);


 $count = 0;
 $total = 0;
 while (mysqli_stmt_fetch($stmt)) {
 if ($count == 0) {
 echo '<h3>' . htmlspecialchars($first . ' ' . $last) . '</h3>';
 echo '<p>Class: ' . htmlspecialchars($class) . '</p>';

 echo '<p>Term ' . $term . ', ' . $year . '</p>';
 echo '<table border="1" cellpadding="8">';
 echo '<tr><th>Subject</th><th>Mark (%)</th></tr>';
 }
 echo '<tr><td>' . htmlspecialchars($subject) . '</td>';
 echo '<td>' . htmlspecialchars($mark) . '</td></tr>';
 $total += $mark;
 $count++;
 }
 if ($count > 0) {
 echo '</table><p>Average: ' . number_format($total / $count, 2) . '%</p>';
 } else {
 echo '<p>No results found for this student, term and year.</p>';
 }
 mysqli_stmt_close($stmt);
 $comment_stmt = mysqli_prepare($connection,
 "SELECT teacher_comment, head_teacher_comment
 FROM report_comments
 WHERE student_id = ? AND term = ? AND year = ?");
mysqli_stmt_bind_param($comment_stmt, 'iii', $id, $term, $year);
mysqli_stmt_execute($comment_stmt);
mysqli_stmt_bind_result($comment_stmt, $teacher_comment, $head_teacher_comment);
mysqli_stmt_fetch($comment_stmt);
mysqli_stmt_close($comment_stmt);

echo '<p>Teacher: ' . htmlspecialchars($teacher_comment ?? '') . '</p>';
echo '<p>Head teacher: ' . htmlspecialchars($head_teacher_comment ?? '') . '</p>';
$attendance_stmt = mysqli_prepare($connection,
 "SELECT COUNT(CASE WHEN status = 'Present' THEN 1 END),
 COUNT(CASE WHEN status = 'Absent' THEN 1 END)
 FROM attendance
 WHERE student_id = ? AND attendance_date BETWEEN ? AND ?");

mysqli_stmt_bind_param($attendance_stmt, 'iss', $id, $start_date, $end_date);
mysqli_stmt_execute($attendance_stmt);
mysqli_stmt_bind_result($attendance_stmt, $present, $absent);
mysqli_stmt_fetch($attendance_stmt);
mysqli_stmt_close($attendance_stmt);
echo '<p>Attendance period: ' . htmlspecialchars($start_date) . ' to ' . htmlspecialchars($end_date) . '</p>';

echo '<p>Attendance: Present ' . $present . ', Absent ' . $absent . '</p>';



}
?>
