<?php
require_once __DIR__ . '/access.php';
require_page_access();

include 'db_connect.php';

if (isset($_POST['save'])) {
 $student = (int) $_POST['student_id'];
 $subject = (int) $_POST['subject_id'];
 $term = (int) $_POST['term'];
 $year = (int) $_POST['year'];
 $mark = (float) $_POST['mark'];

 if ($student > 0 && $subject > 0 &&
 $term >= 1 && $term <= 3 &&
 $year >= 2000 && $year <= 2100 &&
 $mark >= 0 && $mark <= 100) {

 $stmt = mysqli_prepare($connection,
 "INSERT INTO result
 (student_id, subject_id, term, year, mark)
 VALUES (?, ?, ?, ?, ?)");

 mysqli_stmt_bind_param($stmt, 'iiiid',
 $student, $subject, $term, $year, $mark);

 if (mysqli_stmt_execute($stmt)) {
 echo '<p>Result saved successfully.</p>';
 } else {
 echo '<p>Could not save the result.</p>';
 }
 mysqli_stmt_close($stmt);
 } else {
 echo '<p>Please enter valid details.</p>';
 }
}

$students = mysqli_query($connection,
 'SELECT * FROM student ORDER BY first_name');
$subjects = mysqli_query($connection,
 'SELECT * FROM subject ORDER BY subject_name');
?>

<link rel="stylesheet" href="badge_background.css">
<h2>Enter a Result</h2>
<form method="post">
 Student:
 <select name="student_id" required>
 <option value="">Select student</option>
 <?php while ($row = mysqli_fetch_assoc($students)) { ?>
 <option value="<?php echo $row['student_id']; ?>">
 <?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?>
 </option>
 <?php } ?>
 </select><br><br>

 Subject:
 <select name="subject_id" required>
 <option value="">Select subject</option>
 <?php while ($row = mysqli_fetch_assoc($subjects)) { ?>
 <option value="<?php echo $row['subject_id']; ?>">
 <?php echo htmlspecialchars($row['subject_name']); ?>
 </option>
 <?php } ?>
 </select><br><br>

 Term: <select name="term">
 <option>1</option><option>2</option><option>3</option>
 </select><br><br>
 Year: <input type="number" name="year" value="2026" min="2000" max="2100" required><br><br>
 Mark (%): <input type="number" name="mark" min="0" max="100" step="0.01" required><br><br>
 <button type="submit" name="save">Save result</button>
</form>

<h2>Saved Results</h2>
<table border="1" cellpadding="8">
 <tr><th>Student</th><th>Subject</th><th>Term</th><th>Year</th><th>Mark (%)</th></tr>
 <?php
 $results = mysqli_query($connection,
 "SELECT student.first_name, student.last_name,
 subject.subject_name, result.term, result.year, result.mark
 FROM result
 JOIN student ON result.student_id = student.student_id
 JOIN subject ON result.subject_id = subject.subject_id
 ORDER BY result.result_id DESC");

 while ($row = mysqli_fetch_assoc($results)) {
 echo '<tr>';
 echo '<td>' . htmlspecialchars($row['first_name'] . ' ' . $row['last_name']) . '</td>';
 echo '<td>' . htmlspecialchars($row['subject_name']) . '</td>';
 echo '<td>' . htmlspecialchars($row['term']) . '</td>';
 echo '<td>' . htmlspecialchars($row['year']) . '</td>';
 echo '<td>' . htmlspecialchars($row['mark']) . '</td>';
 echo '</tr>';
 }
 ?>
</table>
