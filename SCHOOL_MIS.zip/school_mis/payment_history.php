<?php
require_once __DIR__ . '/access.php';
require_page_access();

include 'db_connect.php';

$payments = mysqli_query($connection,
 "SELECT s.first_name, s.last_name, f.term, f.year,
 p.payment_date, p.amount_paid
 FROM payment p
 JOIN fee_assessment f ON p.assessment_id = f.assessment_id
 JOIN student s ON f.student_id = s.student_id
 ORDER BY p.payment_date DESC, p.payment_id DESC");
?>

<link rel="stylesheet" href="badge_background.css">
<h2>Payment History</h2>
<table border="1" cellpadding="8">
 <tr>
 <th>Student</th><th>Term</th><th>Year</th>
 <th>Payment date</th><th>Amount paid (UGX)</th>
 </tr>
 <?php while ($row = mysqli_fetch_assoc($payments)) { ?>
 <tr>
 <td><?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></td>
 <td><?php echo htmlspecialchars($row['term']); ?></td>
 <td><?php echo htmlspecialchars($row['year']); ?></td>
 <td><?php echo htmlspecialchars($row['payment_date']); ?></td>
 <td><?php echo number_format((float) $row['amount_paid'], 2); ?></td>
 </tr>
 <?php } ?>
</table>
