<?php
session_start();

// Hide the navigation link printed by db_connect.php.
ob_start();
include 'db_connect.php';
ob_end_clean();



if ($_SERVER['REQUEST_METHOD'] === 'POST') {
 $username = trim($_POST['username'] ?? '');
 $password = $_POST['password'] ?? '';

 $stmt = mysqli_prepare($connection,
 'SELECT user_id, password_hash, role FROM users WHERE username = ?');

 if (!$stmt) {
 exit('Could not check the user account.');
 }

 mysqli_stmt_bind_param($stmt, 's', $username);
 mysqli_stmt_execute($stmt);
 mysqli_stmt_bind_result($stmt, $user_id, $password_hash, $role);

 if (mysqli_stmt_fetch($stmt) && password_verify($password, $password_hash)) {
 mysqli_stmt_close($stmt);
 session_regenerate_id(true);
 $_SESSION['user_id'] = $user_id;
 $_SESSION['username'] = $username;
 $_SESSION['role'] = $role;
 header('Location: index.php');
 exit;
 }

 mysqli_stmt_close($stmt);
 $message = 'Incorrect username or password.';
}
?>

<link rel="stylesheet" href="badge_background.css">
<h2>School MIS Login</h2>


<form method="post">
 <p>Username: <input type="text" name="username" required></p>
 <p>Password: <input type="password" name="password" required></p>
 <button type="submit">Log in</button>
</form>

