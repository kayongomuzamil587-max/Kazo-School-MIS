<?php
require_once __DIR__ . '/access.php';
require_page_access();

include 'db_connect.php';

if (isset($_POST['save'])) {
 $student = (int) $_POST['student_id'];
 $term = (int) $_POST['term'];
 $year = (int) $_POST['year'];
 $teacher = trim($_POST['teacher_comment']);
 $head = trim($_POST['head_teacher_comment']);

 if ($student > 0 && $term >= 1 && $term <= 3 &&
 $year >= 2000 && $year <= 2100 &&
 ($teacher != '' || $head != '')) {

 $stmt = mysqli_prepare($connection,
 "INSERT INTO report_comments
 (student_id, term, year, teacher_comment, head_teacher_comment)
 VALUES (?, ?, ?, ?, ?)
 ON DUPLICATE KEY UPDATE
 teacher_comment = VALUES(teacher_comment),
 head_teacher_comment = VALUES(head_teacher_comment)");
 mysqli_stmt_bind_param($stmt, 'iiiss',
 $student, $term, $year, $teacher, $head);

 if (mysqli_stmt_execute($stmt)) {
 echo '<p>Comments saved successfully.</p>';
 } else {
 echo '<p>Could not save comments.</p>';
 }
 mysqli_stmt_close($stmt);
 } else {
 echo '<p>Please enter valid details and at least one comment.</p>';
 }
}

$students = mysqli_query($connection,
 'SELECT student_id, first_name, last_name FROM student ORDER BY first_name');
?>

<link rel="stylesheet" href="badge_background.css">
<h2>Enter Report Comments</h2>
<form method="post">
 Student:
 <select name="student_id" required>
 <option value="">Select student</option>
 <?php while ($row = mysqli_fetch_assoc($students)) { ?>
 <option value="<?php echo (int)$row['student_id']; ?>">
 <?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?>
 </option>
 <?php } ?>
 </select><br><br>

 Term: <select name="term">
 <option>1</option><option>2</option><option>3</option>
 </select><br><br>
 Year: <input type="number" name="year" value="2026" min="2000" max="2100" required><br><br>
 Teacher's comment:<br>
 <textarea name="teacher_comment" rows="3" cols="40"></textarea><br><br>
 Head teacher's comment:<br>
 <textarea name="head_teacher_comment" rows="3" cols="40"></textarea><br><br>
 <button type="submit" name="save">Save comments</button>
</form>

<h2>Saved Comments</h2>
<table border="1" cellpadding="8">
 <tr><th>Student</th><th>Term</th><th>Year</th><th>Teacher</th><th>Head teacher</th></tr>
 <?php
 $comments = mysqli_query($connection,
 "SELECT s.first_name, s.last_name, c.term, c.year,
 c.teacher_comment, c.head_teacher_comment
 FROM report_comments c
 JOIN student s ON c.student_id = s.student_id
 ORDER BY c.comment_id DESC");
 while ($row = mysqli_fetch_assoc($comments)) {
 echo '<tr>';
 echo '<td>' . htmlspecialchars($row['first_name'] . ' ' . $row['last_name']) . '</td>';
 echo '<td>' . htmlspecialchars($row['term']) . '</td>';
 echo '<td>' . htmlspecialchars($row['year']) . '</td>';
 echo '<td>' . htmlspecialchars($row['teacher_comment'] ?? '') . '</td>';
 echo '<td>' . htmlspecialchars($row['head_teacher_comment'] ?? '') . '</td>';
 echo '</tr>';
 }
 ?>
</table>
