<?php
require_once __DIR__ . '/access.php';
require_page_access();

include 'db_connect.php';

if (isset($_POST['save'])) {
 $student = (int) $_POST['student_id'];
 $term = (int) $_POST['term'];
 $year = (int) $_POST['year'];
 $amount = (float) $_POST['amount_due'];

 if ($student > 0 && $term >= 1 && $term <= 3 &&
 $year >= 2000 && $year <= 2100 && $amount > 0) {
 $stmt = mysqli_prepare($connection,
 "INSERT INTO fee_assessment
 (student_id, term, year, amount_due)
 VALUES (?, ?, ?, ?)");
 mysqli_stmt_bind_param($stmt, 'iiid',
 $student, $term, $year, $amount);

 if (mysqli_stmt_execute($stmt)) {
 echo '<p>Fee assessment saved successfully.</p>';
 } else {
 echo '<p>Could not save fee assessment.</p>';
 }
 mysqli_stmt_close($stmt);
 } else {
 echo '<p>Please enter valid details.</p>';
 }
}
$students = mysqli_query($connection,
 'SELECT * FROM student ORDER BY first_name');
?>
F
<link rel="stylesheet" href="badge_background.css">
<h2>Enter Fee Assessment</h2>
<form method="post">
 Student:
 <select name="student_id" required>
 <option value="">Select student</option>
 <?php while ($row = mysqli_fetch_assoc($students)) { ?>
 <option value="<?php echo $row['student_id']; ?>">
 <?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?>
 </option>
 <?php } ?>
 </select><br><br>

 Term: <select name="term">
 <option>1</option><option>2</option><option>3</option>
 </select><br><br>
 Year: <input type="number" name="year" value="2026" min="2000" max="2100" required><br><br>
 Amount due (UGX): <input type="number" name="amount_due" min="0.01" step="0.01" required><br><br>
 <button type="submit" name="save">Save assessment</button>
</form>

<h2>Fee Assessments</h2>
<table border="1" cellpadding="8">
 <tr><th>ID</th><th>Student</th><th>Term</th><th>Year</th><th>Amount due (UGX)</th></tr>
 <?php
 $fees = mysqli_query($connection,
 'SELECT fee_assessment.*, student.first_name, student.last_name
 FROM fee_assessment
 JOIN student ON fee_assessment.student_id = student.student_id
 ORDER BY fee_assessment.assessment_id DESC');

 while ($row = mysqli_fetch_assoc($fees)) {
 echo '<tr>';
 echo '<td>' . htmlspecialchars($row['assessment_id']) . '</td>';
 echo '<td>' . htmlspecialchars($row['first_name'] . ' ' . $row['last_name']) . '</td>';
 echo '<td>' . htmlspecialchars($row['term']) . '</td>';
 echo '<td>' . htmlspecialchars($row['year']) . '</td>';
 echo '<td>' . htmlspecialchars($row['amount_due']) . '</td>';
 echo '</tr>';
 }
 ?>
</table>
