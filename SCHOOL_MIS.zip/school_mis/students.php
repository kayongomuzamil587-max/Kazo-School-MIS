<?php
require_once __DIR__ . '/access.php';
require_page_access();

include 'db_connect.php';

if (isset($_POST['save'])) {
 $first = trim($_POST['first_name']);
 $last = trim($_POST['last_name']);
 $dob = $_POST['date_of_birth'];
 $class = (int) $_POST['class_id'];

 if ($first != '' && $last != '' && $dob != '' && $class > 0) {
 $stmt = mysqli_prepare($connection,
 "INSERT INTO student (first_name, last_name, date_of_birth, class_id)
 VALUES (?, ?, ?, ?)");
 mysqli_stmt_bind_param($stmt, "sssi", $first, $last, $dob, $class);

 if (mysqli_stmt_execute($stmt)) {
 echo '<p>Student saved successfully.</p>';
 } else {
 echo '<p>Could not save student.</p>';
 }
 mysqli_stmt_close($stmt);
 } else {
 echo '<p>Please complete all fields.</p>';
 }
}

$classes = mysqli_query($connection, "SELECT * FROM class ORDER BY class_name");
?>

<link rel="stylesheet" href="badge_background.css">
<h2>Register a Student</h2>
<form method="post">
 First name: <input type="text" name="first_name" required><br><br>
 Last name: <input type="text" name="last_name" required><br><br>
 Date of birth: <input type="date" name="date_of_birth" required><br><br>
 Class:
 <select name="class_id" required>
 <option value="">Select class</option>
 <?php while ($row = mysqli_fetch_assoc($classes)) { ?>
 <option value="<?php echo $row['class_id']; ?>">
 <?php echo htmlspecialchars($row['class_name']); ?>
 </option>
 <?php } ?>
 </select><br><br>
 <button type="submit" name="save">Save student</button>
</form>

<h2>Student Records</h2>
<input type="text" id="studentSearch" placeholder="Search by name">

<table id="studentTable"table border="1" cellpadding="8">
 <tr>
 <th>ID</th><th>First name</th><th>Last name</th>
 <th>Date of birth</th><th>Class</th>
 </tr>
 <?php
 $students = mysqli_query($connection,
 "SELECT student.*, class.class_name FROM student
 JOIN class ON student.class_id = class.class_id
 ORDER BY student.student_id DESC");

 while ($row = mysqli_fetch_assoc($students)) {
 echo '<tr>';
 echo '<td>' . htmlspecialchars($row['student_id']) . '</td>';
 echo '<td>' . htmlspecialchars($row['first_name']) . '</td>';
 echo '<td>' . htmlspecialchars($row['last_name']) . '</td>';
 echo '<td>' . htmlspecialchars($row['date_of_birth']) . '</td>';
 echo '<td>' . htmlspecialchars($row['class_name']) . '</td>';
 echo '</tr>';
 }
 ?>
</table>

<script>
document.getElementById('studentSearch').addEventListener('input', function () {
 let search = this.value.toLowerCase();
 let rows = document.querySelectorAll('#studentTable tr');

 for (let i = 1; i < rows.length; i++) {
 let name = rows[i].cells[1].textContent + ' ' +
 rows[i].cells[2].textContent;
 rows[i].style.display = name.toLowerCase().includes(search) ? '' : 'none';
 }
});
</script>


