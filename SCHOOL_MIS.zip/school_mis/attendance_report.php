<?php
require_once __DIR__ . '/access.php';
require_page_access();

include 'db_connect.php';

$report = mysqli_query($connection,
 "SELECT s.student_id, s.first_name, s.last_name,
 SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS present_days,
 SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS absent_days
 FROM student s
 LEFT JOIN attendance a ON s.student_id = a.student_id
 GROUP BY s.student_id, s.first_name, s.last_name
 ORDER BY s.first_name, s.last_name");
?>

<link rel="stylesheet" href="badge_background.css">
<h2>Attendance Summary Report</h2>
<p>All recorded dates are included.</p>
<table border="1" cellpadding="8">
 <tr><th>Student</th><th>Present</th><th>Absent</th></tr>
 <?php while ($row = mysqli_fetch_assoc($report)) { ?>
 <tr>
 <td><?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></td>
 <td><?php echo $row['present_days']; ?></td>
 <td><?php echo $row['absent_days']; ?></td>
 </tr>
 <?php } ?>
</table>
