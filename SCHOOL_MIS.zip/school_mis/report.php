<?php
require_once __DIR__ . '/access.php';
require_page_access();

include 'db_connect.php';

$student_query = mysqli_query($connection,
 "SELECT COUNT(*) AS total FROM student");
$student_row = mysqli_fetch_assoc($student_query);

$fees_query = mysqli_query($connection,
 "SELECT COALESCE(SUM(amount_due), 0) AS total FROM fee_assessment");
$fees_row = mysqli_fetch_assoc($fees_query);

$payments_query = mysqli_query($connection,
 "SELECT COALESCE(SUM(amount_paid), 0) AS total FROM payment");
$payments_row = mysqli_fetch_assoc($payments_query);

$balance = $fees_row['total'] - $payments_row['total'];
?>

<link rel="stylesheet" href="badge_background.css">
<h2>School Summary Report</h2>
<p>Totals include all recorded terms and years.</p>

<table border="1" cellpadding="8">
 <tr><th>Information</th><th>Total</th></tr>
 <tr>
 <td>Registered students</td>
 <td><?php echo $student_row['total']; ?></td>
 </tr>
 <tr>
 <td>Fees assessed (UGX)</td>
 <td><?php echo number_format($fees_row['total'], 2); ?></td>
 </tr>
 <tr>
 <td>Payments received (UGX)</td>
 <td><?php echo number_format($payments_row['total'], 2); ?></td>
 </tr>
 <tr>
 <td>Overall balance (UGX)</td>
 <td><?php echo number_format($balance, 2); ?></td>
 </tr>
</table>
