<?php
/**
 * Enforces access for pages in the school_mis directory.
 * Unknown filenames are denied so new pages cannot become public by accident.
 */
function require_page_access(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    $page = basename($_SERVER['SCRIPT_NAME'] ?? '');
    $page_roles = [
        'index.php' => [],
        'students.php' => ['admin'],
        'results.php' => ['teacher'],
        'attendance.php' => ['teacher'],
        'comments.php' => ['teacher', 'head_teacher'],
        'fees.php' => ['bursar'],
        'payments.php' => ['bursar'],
        'payment_history.php' => ['bursar'],
        'report.php' => ['head_teacher'],
        'academic_report.php' => ['head_teacher'],
        'attendance_report.php' => ['head_teacher'],
        'report_card.php' => ['admin', 'teacher', 'head_teacher'],
    ];

    if (!array_key_exists($page, $page_roles)) {
        http_response_code(403);
        exit('Access denied.');
    }

    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }

    if ($page_roles[$page] !== []
        && !in_array($_SESSION['role'] ?? '', $page_roles[$page], true)) {
        http_response_code(403);
        exit('Access denied.');
    }
}
