<?php
require_once __DIR__ . '/access.php';
require_page_access();

include 'db_connect.php';

if (isset($_POST['save'])) {
 $assessment = (int) $_POST['assessment_id'];
 $date = $_POST['payment_date'];
 $amount = (float) $_POST['amount_paid'];

 if ($assessment > 0 && $date != '' && $amount > 0) {
 $stmt = mysqli_prepare($connection,
 "INSERT INTO payment
 (assessment_id, payment_date, amount_paid)
 VALUES (?, ?, ?)");
 mysqli_stmt_bind_param($stmt, 'isd',
 $assessment, $date, $amount);

 if (mysqli_stmt_execute($stmt)) {
 echo '<p>Payment saved successfully.</p>';
 } else {
 echo '<p>Could not save payment.</p>';
 }
 mysqli_stmt_close($stmt);
 } else {
 echo '<p>Please enter valid details.</p>';
 }
}

$assessments = mysqli_query($connection,
 "SELECT fee_assessment.*, student.first_name, student.last_name
 FROM fee_assessment
 JOIN student ON fee_assessment.student_id = student.student_id
 ORDER BY fee_assessment.assessment_id DESC");
?>

<link rel="stylesheet" href="badge_background.css">
<h2>Record a Payment</h2>
<form method="post">
 Fee assessment:
 <select name="assessment_id" required>
 <option value="">Select assessment</option>
 <?php while ($row = mysqli_fetch_assoc($assessments)) { ?>
 <option value="<?php echo $row['assessment_id']; ?>">
 <?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?>
 - Term <?php echo $row['term']; ?>,
 <?php echo $row['year']; ?>
 - UGX <?php echo $row['amount_due']; ?>
 </option>
 <?php } ?>
 </select><br><br>

 Payment date: <input type="date" name="payment_date" required><br><br>
 Amount paid (UGX): <input type="number" name="amount_paid" min="0.01" step="0.01" required><br><br>
 <button type="submit" name="save">Save payment</button>
</form>

<h2>Fee Balances</h2>
<table border="1" cellpadding="8">
 <tr>
 <th>Student</th><th>Term</th><th>Year</th>
 <th>Amount due</th><th>Total paid</th><th>Balance</th>
 </tr>
 <?php
 $balances = mysqli_query($connection,
 "SELECT s.first_name, s.last_name, f.term, f.year, f.amount_due,
 COALESCE(SUM(p.amount_paid), 0) AS total_paid
 FROM fee_assessment f
 JOIN student s ON f.student_id = s.student_id
 LEFT JOIN payment p ON f.assessment_id = p.assessment_id
 GROUP BY f.assessment_id, s.first_name, s.last_name,
 f.term, f.year, f.amount_due
 ORDER BY f.assessment_id DESC");

 while ($row = mysqli_fetch_assoc($balances)) {
 $balance = $row['amount_due'] - $row['total_paid'];
 echo '<tr>';
 echo '<td>' . htmlspecialchars($row['first_name'] . ' ' . $row['last_name']) . '</td>';
 echo '<td>' . htmlspecialchars($row['term']) . '</td>';
 echo '<td>' . htmlspecialchars($row['year']) . '</td>';
 echo '<td>' . number_format((float)$row['amount_due'], 2) . '</td>';
 echo '<td>' . number_format((float)$row['total_paid'], 2) . '</td>';
 echo '<td>' . number_format($balance, 2) . '</td>';
 echo '</tr>';
 }
 ?>
</table>
