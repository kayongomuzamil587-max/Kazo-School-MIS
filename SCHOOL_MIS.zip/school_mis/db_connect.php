<?php
if (session_status() === PHP_SESSION_NONE) {
 session_start();
}

if (basename($_SERVER['SCRIPT_NAME']) !== 'login.php'
 && !isset($_SESSION['user_id'])) {
 header('Location: login.php');
 exit;
}


$connection = mysqli_connect("localhost", "root", "", "school_mis");

if (!$connection) {
 die("Database connection failed.");
}

//echo "Database connected successfully.";
$page = basename($_SERVER['SCRIPT_NAME']);
if ($page != 'index.php' && $page != 'report_card.php') {
 echo '<p><a href="index.php">Back to Home</a></p>';
}

?>
