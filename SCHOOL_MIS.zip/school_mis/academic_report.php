<?php
require_once __DIR__ . '/access.php';
require_page_access();

include 'db_connect.php';

$report = mysqli_query($connection,
 "SELECT subject.subject_name,
 COUNT(result.result_id) AS entries,
 AVG(result.mark) AS average_mark
 FROM result
 JOIN subject ON result.subject_id = subject.subject_id
 GROUP BY subject.subject_id, subject.subject_name
 ORDER BY subject.subject_name");
?>

<link rel="stylesheet" href="badge_background.css">
<h2>Academic Summary Report</h2>
<p>All recorded terms and years are included.</p>

<table border="1" cellpadding="8">
 <tr>
 <th>Subject</th>
 <th>Results recorded</th>
 <th>Average mark (%)</th>
 </tr>
 <?php while ($row = mysqli_fetch_assoc($report)) { ?>
 <tr>
 <td><?php echo htmlspecialchars($row['subject_name']); ?></td>
 <td><?php echo $row['entries']; ?></td>
 <td><?php echo number_format((float) $row['average_mark'], 2); ?></td>
 </tr>
 <?php } ?>
</table>
