<?php
require_once __DIR__ . '/access.php';
require_page_access();

$school = "Kazo Muslim Secondary School";
?>
<!DOCTYPE html>
<html>
<head>
 <title> KMSS MIS</title>
 <style>
 body {
 font-family: Arial;
 background: #f0f4f8;
 margin: 0;
 }
 header {
 background: #1f4e79;
 color: white;
 padding: 20px;
 }
 main {
 margin: 30px;
 padding: 20px;
 background: rgba(255, 255, 255, 0.3);
 }
 main a {
 display: inline-block;
 background: #164678;
 color: white;
 padding: 10px 15px;
 text-decoration: none;
 border-radius: 5px;
}

main a:hover {
 background: #0b2d50;
}

 </style>
 <link rel="stylesheet" href="badge_background.css">
</head>
<body>
 <header>
 <h1><?php echo $school; ?></h1>
 <p>School Management Information System</p>
 </header>
 <main>
 <link rel="stylesheet" href="badge_background.css">
<h2>Welcome</h2>
 <p>This is our school MIS prototype.</p>
 <p><a href="students.php">Student Records</a></p>
<p><a href="results.php">Results</a></p>
<p><a href="fees.php">Fee Assessments</a></p>
<p><a href="payments.php">Payments and Balances</a></p>
<p><a href="attendance.php">Attendance</a></p>
<p><a href="report.php">School Summary Report</a></p>
<p><a href="academic_report.php">Academic Report</a></p>
<p><a href="attendance_report.php">Attendance Report</a></p>
<p><a href="report_card.php">Student Results Report</a></p>
<p><a href="comments.php">Enter Report Comments</a></p>
<p><a href="payment_history.php">Payment History</a></p>



 </main>
</body>
</html>

